package com.example.gibson.carlife.Services;

public abstract class RequestManager {
  public static String host = "http://18.219.196.79";
  public static int width = 0;
  public static int height = 0;

}
