package com.example.gibson.carlife.View;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.example.gibson.carlife.R;

public class OrderDetailActivity extends AppCompatActivity {

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.order_detail_list_view_item);
  }
}
