package com.example.gibson.carlife.Model.Order;

public enum OrderStatus {
  cart, unpay, paid, cancel, pending_refund
}